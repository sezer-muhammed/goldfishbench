# GoldfishBench v1: scientific supplementary results

This supplement accompanies **GoldfishBench: Separating Intervention Need from
the Suitability of a Named Recipient**, by Muhammed Izzet Sezer. It contains
the scientific summaries referenced by the paper. The work is exploratory,
post-hoc and based on controlled synthetic scenarios; independent human
semantic reviews completed: **0**. Software preservation checks are not human
annotation, peer review or evidence of confirmatory validity.

## Files and scope

`results.json` supplies all 21 model/rendering conditions, all 56 held-facts
rendering contrasts, source-wave observation summaries, source-stratified
component panels, response coverage and missingness sensitivity bounds.
`verification.json` binds the exported file to its source summary and records
deterministic preservation and content checks. Original scientific metric
objects are retained exactly; additional source-wave summaries and bounds are
explicitly separated from those objects.

This is a release of scientific summaries. It does not release scenario text,
raw response archives, evaluation software, the private research repository,
or measurements from another paper. A hash identifies an underlying frozen
artifact without asserting that the underlying artifact is included here.

## Evaluation inventory and provenance

The analytical suite contains **662 scenario families** across four domains:
customer support (164), internal IT (168), document access (163) and workflow
escalation (167). Each family has four need-by-suitability cells under three
renderings, giving 7,944 intended joint questions per model and **55,608**
across seven model conditions. There are **55,603 usable joint answers**.
Variants and sibling cells are not independent scenarios.

The source-construction waves are `replication_v080` (32 families) and
`precision_v090` (630 families). Their original measurements were acquired on
2026-10-13 and 2026-10-14, respectively. The original five-model suite was
selected for usable joint responses, without filtering by correctness.
Complete-case selection can still bias the observed suite. Jev 1.14 and
Decider V1.2 were measured on the same fixed question inventory on 2026-10-18;
their source-wave labels identify question construction, not their acquisition
dates. This combination is neither one physical execution nor a retroactively
preregistered confirmatory trial.

The component panel comprises 133 families: all 32 from the earlier wave and
101 from the later wave. It has 532 intended worlds per rendering and a
different source mixture from the joint suite. CFR therefore describes the
diagnostic panel rather than population prevalence across all 662 families.

Exact served model versions and providers are listed in `model_conditions`.
Jev's two versions are distinct conditions, not independent architectures.
Version dates for the two Cloudflare conditions are undocumented; their
undated served names must not be interpreted as fixed checkpoint dates.

## Reading the results

All rates, differences and interval endpoints are **proportions**. Multiply
rates by 100 for percentages and differences by 100 for percentage points.
The canonical policy is `S = C AND U AND A`, `Y = N AND S`. Authorization and
availability are true in the integrated core; capability determines suitability.
Always NO achieves 75% raw accuracy but only 50% balanced accuracy.

- `conditions` retains each need contrast, two need-state error counts,
  matched-pair patterns and family scores, joint confusion matrices and balanced
  accuracy, all-four-cells accuracy, component accuracy, CFR and predicted-AND
  comparisons. `component_panel_by_acquisition_wave` retains source-specific
  component/composition diagnostics.
- `rhetorical_contrasts` retains both pressure conditions in every policy cell
  for every model: 7 models × 2 changes × 4 cells = 56. Positive `error_delta`
  means more errors after the rendering change; negative and zero effects are
  retained. Names and quoted prose change together, so this is not a pure name
  intervention.
- `source_wave_observation_summaries` groups the exact family-level need or
  error-change scores by construction wave, with intended, usable and unavailable
  family counts. Its means are descriptive source strata, not fresh measurements.
- Each `bootstrap` and `cluster_sensitivity` object retains the original
  10,000-resample metadata, seeds, family/domain/source strata and intervals.
  Topic and operation-template sensitivities preserve source mixture weights;
  older cases without comparable metadata remain individual clusters. These
  one-way sensitivities do not fully resolve crossed template dependence.

All uncertainty intervals are descriptive and unadjusted for multiplicity.
The `template` sensitivity key denotes operation-recipe clustering in the
paper. A `[0, 0]` bootstrap interval in an all-correct finite sample does not
establish zero population risk. Observed coherence or component correctness
does not demonstrate an internal neural mechanism.

## Missingness and technical recovery

Jev 1.14 has 7,939/7,944 usable joint answers and 3,188/3,192 usable component
answers. Five initial service failures were recovered once; valid scientific
answers were never repeated. Nine later service failures remain unavailable:
five joint and four component questions. Decider V1.2 has all 11,136 intended
joint/component answers usable and correct. Earlier-model component availability
can also differ from joint-core completeness; the per-condition triplet counts
are authoritative.

Unavailable responses never become NO. `conditional_accuracy` uses usable
answers; `overall_success` uses the full intended denominator and counts only
observed correct responses as successes. Need contrasts use matched usable
pairs and retain full-intended worst-case bounds. The separately labelled
`derived_full_intended_bounds` additionally supplies conservative rhetorical
error-change bounds and overall joint-accuracy bounds. Missingness bounds are
sensitivity analyses, not confidence intervals. CFR uses only usable N/S/Y
triplets with both components correct; its denominator is reported and a zero
denominator produces null (NA).

## Preserved original primary endpoint

`original_frozen_primary648` preserves the prespecified Luna Decisions
name/prose need contrast from the earlier precision extension, separately
from the paper's later 662-family post-hoc aggregation. There were 1,200
intended pairs, 648 usable pairs and 552 unavailable pairs. The observed need
contrast is 0.7006172839506173, with its original 95% family interval
[0.6651234567901234, 0.7361111111111112]. The target total width of 0.05 was
not achieved. Full-intended worst-case bounds are [-0.08166666666666667,
0.8383333333333334], demonstrating the separate effect of incomplete coverage.

The original primary metric retains exact family scores, need-state counts,
error categories, component diagnostics, topic/recipe sensitivities and
prespecified target fields. Its 15-condition source-coverage summary preserves
intended, observed, usable and unavailable question counts and distinguishes
unattempted questions from technical errors. No error is relabelled as NO.
This earlier endpoint does not include the two later models. Its source
summary, analysis plan and analyzer are bound by hashes. Underlying private
raw archives and acquisition records are not publicly included; the supplement
provides the disclosed scientific summaries and coverage, not those archives.

## Integrity and interpretation

The provenance hashes bind the seven-model summary, source datasets, earlier
analysis summaries and analyzer. No model was queried to produce this export.
All 21 condition objects and all 56 contrast objects compare exactly with their
attributable source fields. The scientific export uses an explicit recursive
field allowlist and rejects unrelated or operational content.

Strong failures and successful models are both retained. These results support
model-dependent policy sensitivity in this finite controlled suite; they do
not demonstrate a universal persuasion tactic, production attack success,
an architectural cause, or representative real-world prevalence. Independent
human semantic review, held-out language and realistic authoritative policies
remain outstanding.
